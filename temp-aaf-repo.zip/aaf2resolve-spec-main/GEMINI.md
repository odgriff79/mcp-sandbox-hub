# GEMINI.md
- Prioritize writing missing tests first.
- If test fails due to unclear contract, open an issue proposing a spec tweak.
