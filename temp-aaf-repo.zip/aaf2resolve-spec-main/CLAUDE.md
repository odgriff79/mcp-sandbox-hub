# CLAUDE.md
- Prefer minimal deps; preserve existing public APIs.
- When opening PRs, run `make ci` locally (or simulate) and include output.
