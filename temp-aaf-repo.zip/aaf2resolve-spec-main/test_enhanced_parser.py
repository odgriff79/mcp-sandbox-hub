#!/usr/bin/env python
"""
Test script for enhanced AAF parser with deep traversal and keyframe extraction.
"""

import json
import sys
import traceback
from pathlib import Path

# ... paste the entire test script content here ...
