# Required Fields (current stance — editable)
- Event: name, timeline offsets, duration
- Source: clip name, original path/URL/UMID (prefer originals), tape/disk labels
- Effect: class + decoded ID (e.g., "AVX2 Effect : EFF2_STABILIZE")
- Keyframes: placeholder (not persisted yet)
- Provenance: parser version + timestamp
