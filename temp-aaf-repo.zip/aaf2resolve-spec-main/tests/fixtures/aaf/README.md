What you need to do next

Put your files here:

tests/fixtures/aaf/candidate.aaf

tests/fixtures/aaf/candidate_legacy.json (preferred)
or tests/fixtures/aaf/candidate_legacy.csv (must contain a canonical_json or json column with the blob)

Run just this test (it will skip if fixtures not found):
